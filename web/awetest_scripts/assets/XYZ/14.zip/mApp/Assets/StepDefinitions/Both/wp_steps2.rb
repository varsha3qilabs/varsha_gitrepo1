Then /^I Delete the post$/ do
  	if query("TableViewCellDeleteConfirmationControl").empty?
  	touch("view marked:'My Sample Blog 1'")
  	sleep 1
  	touch("ToolbarButton index:3")
  	sleep 1
  	touch("button marked:'Delete'")
  	#binding.pry
  	else
  	touch("TableViewCellDeleteConfirmationControl")
  	end
end  

Then /^I (?:press|touch) the button "([^\"]*)"$/ do |name|
  
  if query("button marked:'#{name}'").empty?
    sleep 2
  else
  touch("button marked:'#{name}'")
  sleep(STEP_PAUSE)
  end
end

Then /^I hit Remove$/ do
	touch("TableViewCellDeleteConfirmationControl")
end	