require 'pry'

STEP_PAUSE = (ENV['STEP_PAUSE'] || 0.5).to_f

Then /^I debug$/ do
	binding.pry
end

Given /^I am on welcome Screen$/ do
end


Then /^I delete the blog$/ do
	touch("ImageButton id:'deletePost'")
end

Then /^I touch the text "(.*?)"$/ do |txt|
	touch("WebView css:'input[type=submit]',value=>'#{txt}'")
end

Then /^I should Press the Add Post$/ do
	if query("button marked:'navbar add'").empty?
	touch("SwappableImageView")
	else
	touch("button marked:'navbar add'")
	end
end

Then /^I should Press the "(.*?)" Button$/ do |bname|
	touch("button marked:'#{bname}'")
end

Then /^I should click on Blog post$/ do
	touch("label marked:'Tap here to begin writing'")
end

Then /^I Enter Blog Text "(.*?)"$/ do |blogText|
 	keyboard_enter_text(blogText)
end

Then /^I Set Title for Post as "(.*?)"$/ do |blogtitle|
 	#touch("TextField index:0")
 	#keyboard_enter_text(blogtitle)
 	set_text("textField index:0", blogtitle)
end

Then /^I set Tags for Post as "(.*?)"$/ do |blogtag|
 	set_text("textField index:1", blogtag)
end 

Then /^I enter "(.*?)" for URL$/ do |url|
 	#touch("TextField index:0")
 	#keyboard_enter_text(url)
 	set_text("textField index:0", url)
end

Then /^I should Press Button "(.*?)"$/ do |labelName| 
	touch("label marked:'#{labelName}'")
end

Then /^I enter username "(.*?)"$/ do |usrname|
 	#touch("TextField index:1")
 	#keyboard_enter_text(usrname)
 	set_text("textField index:1", usrname)
end

Then /^I enter password "(.*?)"$/ do |pwd|
  	touch("TextField index:2")
  	keyboard_enter_text(pwd)
#  	set_text("textField index:2", pwd)
end

Then /^I touch plus icon$/ do
 	step ("I touch button number 2")
end