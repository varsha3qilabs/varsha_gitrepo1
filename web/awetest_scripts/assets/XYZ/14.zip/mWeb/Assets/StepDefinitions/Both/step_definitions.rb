

Then /^I enter username "(.*?)"$/ do |value|
   @browser.text_field(:name, "log").set(value)
end

Then /^I enter password "(.*?)"$/ do |value|
   @browser.text_field(:name, "pwd").set(value)
end


Then /^I should see "(.*?)"$/ do |text|
	@browser.text.include?(text)
end

Then /^I press the text "(.*?)" $/ do |text|
	case text
	    when 'link'
	       @browser.link(:text =>text).click
	    when 'button'
	       @browser.button(:id=>text).click
	end
end

Then /^I press the Sign Out Image$/ do |text|
       @browser.li(:id ,"wp-admin-bar-my-account").link.click
end

Then /^I close the browser$/ do |text|
	@browser.close
end
